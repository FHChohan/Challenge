# Data Extraction and Transformation for Data Analytics


# Learning Objectives

- Learn the fundamental concepts and the role that a data engineer plays in data extraction and transformation services
- Learn about the different approaches to extracting or mining data
- Learn how to extract and transform data for data analytics and machine learning
#

# Learning Outcomes

<img src="https://github.com/FHChohan/Challenge/blob/main/Guy1.jpg?raw=true" alt="LearningObjectives" width="300" height="200" id="LO"/>

- **LO1** - Demonstrates an understanding of the basic data extraction and transformation concepts.
- **LO2** - Able to demonstrate the ability to implement a data extraction and transformation tool based on a given case.
- **LO3** - Able to demonstrate the ability to modify existing tools or codes to source and transform data based on given criteria.

#

# <a id="TOC"></a>  Table of Contents
1. ### [Rationale for Data Engineers to perform Data Extraction and Transformation Services](#Introduction)
1. ### [Data Extraction](#DataExtraction)
    2.1 [Different forms of Data Extractions](#Types)
1. ### [Data Transformation](#DataTransformation)
1. ### [Practical  Component](#Prac)
    4.1 [Case Study Definition](#Def)  
    4.2 [System Requirements and Installation of Anaconda](#SysReq)  
        4.3 [Installation Anaconda Installation](#Testing)  
        4.4 [Installing Dependencies](#Dependencies)  
        4.5 [Implementing the Web Crawler](#DevCrawler)  
        4.6 [Merging Extracted Data](#MergeData)  
        4.7 [Data Transformation](#DataTrans)

1. ### [Conclusion](#Conclusion)
1. ### [Assessment Activity](#Assessment)
1. ### [Key Definitions](#Definitions)
1. ### [Reference Table](#Reference)


</br>
</br>


# <a id="Introduction"></a>  1. Rationale for Data Engineers to perform Data Extraction and Transformation Services

As a [Data Engineer](#DataEngineer "Get the Definition") you will be responsible for developing and maintaining an organization's entire data infrastructure. This includes everything from establishing data sources to a variety of storage solutions including cloud-based services.

Orchestrating data pipelines to move data from its source to a data warehouse is one of the primary tasks of a Data Engineer. These pipelines are critical as they allow an organization to have access to its data in order to perform data analytics and interpretation for better decision-making.

However, many Small, Medium and Micro Enterprises (SMMEs) do not have the financial resources to hire a Data Engineer and [Data Scientist](#DS "Get the Definition"). In many instances you will be required to develop your own code to source and transform data needed for processing further down the ETL pipeline for tasks such as [Natural Language Processing](#NLP "Get the Definition") (NLP), [Machine Learning](#ML "Get the Definition") (ML) and Data Visualization. Possessing these critical skills will not only enhance your career but will also give you an added advantage allowing you to better understand the shape and structure of the data required for these tasks.

In previous lessons you learnt how to source and store data using APIs and cloud-based services. However, in this lesson we will teach you how to **analyze and modify existing code to extract and transform data** based on a given case using popular programming languages such as Python or R. <br>

Figure 1 provides an overview of the ETL *(Extract-Transform-Load)* process, which was first introduced and discussed in the previous module: Explore 101. It is critical that you familiarize yourself with it as it provides context to the Data Extraction and Transformation tasks discussed in this lesson.

<div align="center" style="width: 550px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/ETL7.png?raw=true"
     alt="ETL Process"
     style="float: center"
     width=600px height=220/>
     <b>Figure 1 - The ETL Process Overview</b> <br>
     Source: (Qlik, 2020)
</div>
</br>

# <a id="DataExtraction"></a>2. Data Extraction

Data extraction is the first step in the ETL process and refers to the process of retrieving data from different data sources *(generally unstructured data)* required for further processing or storage further down the ETL pipeline. As a Data Engineer is commonly your task to extract and transform unstructured raw data into structurely correct datasets required by analytical processes. In previous lessons, you learnt about APIs and tools *(such as Exchangerate.host and Goldapi.io)* that allowed you to source publicly available data. Additionally, we can download publicly available datasets and use them for training and other non-commercial purposes. 

But what happens when we need to source very specific information for certain industries or purposes? Such information is not freely available! Hence, as a Data Engineer it is vital that you broaden your skill set to include the development or modification of your own [web crawlers](https://en.wikipedia.org/wiki/Web_crawler "Click to learn more on Web Crawlers") also known as a spider in order to source such information. <span style="color: DarkRed; font-family: Sans-Serif; font-size: 13.35px"> At Explore we encourage students to investigate a variety of different approaches to solve complex real-world problems.</span> <br>

### <a id="Types"></a>**2.1 Different forms of Data Extraction**
Data Extraction jobs could be scheduled, or extracted on demand as dictated by business needs and analysis goals. Data are often extracted using one of the three fundamental ways:

- **Update notification:** The is perhaps the easiest approach to extract data from a source system is to have that system issue a notification when a record has been changed. Most database systems support this functionality in order to faciliate database replication.
- **Incremental extraction:** Some data sources do not support automatic update notifications, but are able to identify which records have been modified and provide a log or extract of those records. During subsequent ETL steps, the data extraction code needs to identify and propagate such changes.
- **Full extraction:** Involves the full extraction of all data from a data source. Additionally, these sources provide no form of push/pull update notifications nor modification logs hence updates requires that you repeatedly perform a full extraction.

</br>



### <span style="color: DarkBlue;"> <img src="https://github.com/FHChohan/Challenge/blob/main/Approval.png?raw=true" alt="Additional Resources" width="50" height="50" id="Resources" align=left/> **Useful Resources and Independent Research**</span> 
#####  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; *(Additional research and self practice)* <br><br>

> - #### [Google Trends examples](http://bar.rady.ucsd.edu/DataApi.html "Learn a few Google Trend API examples") - allows you to gather trends on just about any topic.  
> - #### [Google Maps Geocoding API](https://developers.google.com/maps/documentation/geocoding/overview "Google Geocoding API") - Allows you to convert addresses into geographical coordinates and vice versa.  
> - #### [What is ETL?](https://www.qlik.com/us/etl "Google Geocoding API") - Research the ETL process.
</br>

# <a id="DataTransformation"></a>  3. Data Transformation

The second step in the ETL pipeline is the **data transformation** process as illustrated in Figure 1. Data transformation refers to the process of modifying the format, structure/shape, or values of data as demanded by data analytic tasks or business requirements. Traditionally, organizations that implement on-premises data warehouses employ an in-house ETL (Extract-Transform-Load) process resulting in reduced latencies *(delays)*. 

Additionally, some organisations *(due to a myriad of factors)* implement a **Hybrid ETL infrastructure** that implements certain components of their pipeline in-house and others hosted by a trusted Cloud Service Provider (CSP).

 Conversely, organizations nowadays implement cloud-based data warehousing, allowing them to easily scale compute and storage resources through the implementation of cloud-based services such as [AWS EC2](https://aws.amazon.com/ec2/?ec2-whats-new.sort-by=item.additionalFields.postDateTime&ec2-whats-new.sort-order=desc "Click to read more on AWS EC2") for compute capabilities, [DynamoDB](https://en.wikipedia.org/wiki/Amazon_DynamoDB "Click to read more on AWS DynamoDB") for data storage and AWS Data Pipeline for orchestrating data pipelines. Many of these you would have learnt and used in previous lessons.

Data transformation includes several tasks such as [data integration](#DataIntegration), [data migration](#datamigration), [data warehousing](#datawarehousing), and [data wrangling](#datawrangling) in order to move and transform raw, unstructured data into a standard format for process compatibility and to cleanse irrelevant data from the dataset. The level of data transformation depends greatly on data extraction process employed and by the business need.

As a Data Engineer you are commonly tasked with handling data integration, migration and warehousing jobs. Data transformation however, is commonly associated with data wrangling. Whilst traditionally the domain of the Data Scientists, **data wrangling is a critical skill that is being increasely demanded from Data Engineers by many SMMEs. Hence, it is extremely important that you learn this vital skill.**
</br>
</br>

### <span style="color: DarkBlue;"> <img src="https://github.com/FHChohan/Challenge/blob/main/Approval.png?raw=true" alt="Additional Resources" width="50" height="50" id="Resources" align=left/>**Useful Resources and Independent Research**</span> 
#####  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; *(Additional research and self practice)* <br><br>

> - #### [What is Data Wrangling?](https://online.hbs.edu/blog/post/data-wrangling "Learn more about Data Wrangling") - provides you with further information on Data Wrangling.
> - #### [Data Transformation : Complete Guide & Best Practices](https://www.solvexia.com/blog/data-transformation-guide "Learn more on Data Transformation") - Learn more about Data Transformation and Best practices.  
> - #### [Google Cloud DataPrep Tool](https://cloud.google.com/dataprep "Click to open Dataprep") - Dataprep provided by Trifacta is an intelligent cloud data service to visually explore, clean, and prepare data for analysis and machine learning.
> - #### [Hybrid ETL with Azure Data Factory](https://docs.microsoft.com/en-us/azure/architecture/example-scenario/data/hybrid-etl-with-adf "Click to research on Hybrid ETLs") - Research Hybrid ETLs using Microsoft Azure.

In the next sections we will learn about the modification and implementation of data extraction and transformation tools based on a given case.
</br></br>
# <a id="Prac"></a> 4. Practical Component

### <a id="Def"></a>**4.1 Case Study Definition**  
CSRD is a small locally based organisation that deals with Cyber-Security Research and Development tasks. CSRD has been working closely with the South African government for the past 3 years and has provided valuable research and input into the development of the [Cybercrime Act 19 of 2020](https://www.gov.za/documents/cybercrimes-act-19-2020-1-jun-2021-0000). 

CSRD has recently received the MIMECAST report on the [“State of Email Security”](https://www.mimecast.com/state-of-email-security/?utm_medium=semppc&utm_source=googleppc&utm_campaign=soes_2021&utm_term=cyber%20crime&utm_content=un&gclid=Cj0KCQiA2NaNBhDvARIsAEw55hi7pFXb7khn0jJ6T8-izVUNu9_o5CrBkNbfAGHprIxUCaxZk4ccfhkaAsKrEALw_wcB) which revealed that email threats have increased by more than 64% in 2020 as attackers took advantage of the increased digital traffic induced by the COVID-19 pandemic.

Consequently, CSRD has been looking into Natural Language Processing and Machine Learning to help them detect covert based email threats through [Text-based Steganography](https://en.wikipedia.org/wiki/Steganography).

In order to conduct this research, CSRD has contacted you to help them source and transform hundreds of encoded email messages from the [Spammimic website](https://www.spammimic.com/) in order feed it into a machine learning algorithm that will allow them to detect or classify such threats. 

After reviewing their request, you decided to search the internet for sample spammimic datasets but did not find any. Consequently, you have suggested the following to CSRD:
- **a)**	You would develop a web crawler to automatically populate Spammimic with random sentences to generate the encoded messages and store them into individual text files.
- **b)**	You would then merge the files into a single .csv file based on the classification criteria provided by CSRD which is **“Text, Label** *(where "1" indicates a Spammimic-Encoded message and "0" indicates a normal email)*.
- **c)**	Perform data transformation on the raw unstructured data using NLP techniques to prepare the dataset for any machine learning or data analytical tasks they envision.

> **Note:** The fundamental focus of this lesson is on the implementation and modification of the code rather than an in-depth discussion on the development of the code itself. However, descriptive comments have been included in the code extracts to provide some context. Additional resources are recommended to assist you.
  
</br>


<div align="center" style="width: 550px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/pipeline.png?raw=true"
     alt="Development Plan"
     style="float: center"
     width=600px height=220/>
     <b>Figure 2 - Extraction and Transformation Strategy</b> <br>
</div>
</br>

**CSRD Decision Outcome:** 
The management of CSRD has reviewed and approved your strategy.  

***
</br>

### <a id="SysReq"></a>**4.2 System Requirements and Installation**  
Due to the nature of the lesson and security restrictions this practical will be conducted using a locally install Python Development Environment on you computer and not in a cloud platform such as AWS, Google Cloud or Digital Oceans. The rationale is to emulate an in-house or hybrid-based ETL process where data sources for specific information is not publicly available. Additionally, it will provide you with the technical skill and an alternative approach to handling similar real-world challenges.

Before conducting our practical we must ensure that the following key system requirements are met. These include:
</br></br>
<img src="https://github.com/FHChohan/Challenge/blob/main/Man1.png?raw=true" align="left" width="150" height="150" id="Man" /><p> 
><ol><b>
 > <li>Windows 10 Operating System</li>
  ><li>A reliable internet connection</li>
  ><li>Latest version of Anaconda Navigator</li>
  ><li>Installed dependencies NLTK, Pandas and Selenium
  > <li>Google Chrome</li>
</ol></b>
</p></br>

The following steps show you how to install Anaconda - a powerful package manager.</br></br>

> ### <span style="color: DarkRed;"> <img src="https://github.com/FHChohan/Challenge/blob/main/Download.png?raw=true" align="left" alt="Download" width="100" height="100" id="Resources" align=left/>**View or download the CSDR video which will provide you with valuable information and a step-by-step guide on how to perform this practical.**
> #### To view/download click on the link >> [CSDR Practical Video](https://youtu.be/YH7KgrTXgE0)</span> 
</br>

>#### **Step 1 and  2 - Operating System Installation and Internet Connectivity**
1. For these steps we are going to assume that you are already using a copy of the **Microsoft Windows 10 operating system** and that you have a **reliable internet connection.** Once you have ensured this, we are now ready to move onto Step 3.  
</br>

>#### **Step 3: - Installing Anaconda on Windows**
 
Anaconda is a package manager, an environment manager, and Python distribution that contains a collection of many open source packages. This is advantageous when you are working on data science projects.</br>

1. You can download Anaconda by clicking on the link: >> [Anaconda](https://www.anaconda.com/products/individual "Click to download the latest version of Anaconda"). Once the Anaconda webpage loads1. ### [Conclusion](#Conclusion), click on the **"Download"** button as shown in figure 3 marked by the red box.  
</br>
</br>

<div align="center" style="width: 550px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/Anaconda1.png?raw=true"
     alt="ETL Process"
     style="float: center"
     width=2000px height=280/>
     <b>Figure 3 - Installation of Anaconda</b> <br>
</div>
</br>

2. After clicking on the **Download** button you will see the Anaconda installation file being downloaded in the status bar of your web browser as shown in Figure 4.</br></br>


<div align="center" style="width: 550px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/Anaconda2.png?raw=true"
     alt="ETL Process"
     style="float: center"
     width=2000px height=200/>
     <b>Figure 4 - Download Status </b> <br>
</div>
</br>


3. When the installation launches the screen below appears, click on the **Next** button to proceed to the Licensing Agreement.

<div align="center" style="width: 500px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/Anaconda3.png?raw=true"
     alt="ETL Process"
     style="float: center"
     width=2000px height=350/>
     <b>Figure 5 - Launching the Anaconda Installation Process </b> <br>
</div>
</br>

4. When the Licensing Agreement dialog appears, click on the **I Agree** button to accept the licensing agreement.

<div align="center" style="width: 500px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/Anaconda4.png?raw=true"
     alt="ETL Process"
     style="float: center"
     width=2000px height=350/>
     <b>Figure 6 - Licensing Agreement </b></br>
</div>
</b></br>

5. On the next screen you will be prompted to select the **Installation Type**, select **Just Me(recommended)** and then click on the **Next** button.

<div align="center" style="width: 500px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/Anaconda5.png?raw=true"
     alt="ETL Process"
     style="float: center"
     width=2000px height=350/>
     <b>Figure 7 - Selecting the Installation Type </b></br>
</div>
</b></br>


6. On the next dialog, you will be prompted to specify the destination folder for the installation files. Leave it set to its default path as shown in Figure 8 and click on the **Next** button.

<div align="center" style="width: 500px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/Anaconda6.png?raw=true"
     alt="ETL Process"
     style="float: center"
     width=2000px height=350/>
     <b>Figure 8 - Specifying the Destination Folder </b></br>
</div>
</b></br>

7. On the **Advanced Installation Options** dialog, leave both checkboxes unchecked *(do not tick them)*. Simply click on the **Next** button to continue with the installation.

<div align="center" style="width: 500px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/Anaconda7.png?raw=true"
     alt="ETL Process"
     style="float: center"
     width=2000px height=350/>
     <b>Figure 9 - Advanced Installation Options </b></br>
</div>
</b></br>

8. The following dialogs illustrate the final part of the installation process *(You can remove the checks from the two checkboxes on the final dialog)*. Once the Anaconda is installed we are ready to test and install all dependencies required for our project.

<div align="center" style="width: 700px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/Anaconda9.png?raw=true"
     alt="ETL Process"
     style="float: center"
     width=2000px height=300/>
     <b>Figure 10 - Finishing the Installation </b></br>
</div>
</b></br>

### <a id="Testing"></a> **4.3 Verify Anaconda installation**</br>
Now that we have completed the installation of Anaconda, we need to verify that the installation was successful, and that Python and the required dependencies are properly installed. 

#### **4.3.1 To verify the installations of Anaconda and Python we need to perform the following steps:**
>1. Click on the **Windows Search button** on the bottom left-hand corner of your screen.
>1. In the Search Bar type **Anaconda Navigator**, and then click on it as shown in Figure 11.


<div align="center" style="width: 400px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/OpenAna.png?raw=true"
     alt="AnaNavi"
     style="float: center"
     width=2000px height=300/>
     <b>Figure 11 - Opening Anaconda Navigator </b></br>
</div>
</br>

>3. Once the **Anaconda Navigator** has loaded, click on the **Launch** button under the **Powershell Prompt** panel as shown in Figure 12.  


<div align="center" style="width: 500px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/CMDLaunch.png?raw=true"
     alt="AnaNavi"
     style="float: center"
     width=2000px height=280/>
     <b>Figure 12 - Launch Powershell Prompt </b></br>
</div>
</br>

> 4. At the  **Powershell** command prompt, type out the following commands *(remember to press **enter** after each command)* 
</br></br>

```python
> conda --version
```
```python
> python --version
```
<div align="center" style="width: 500px; font-size: 12pts; text-align: center; margin: auto">
<img src="https://github.com/FHChohan/Challenge/blob/main/verifyAna.png?raw=true"
     alt="AnaNavi"
     style="float: center"
     width=2000px height=120/>
     <b>Figure 13 - Verifying Anaconda and Python </b></br>
</div>
</br>

If the versions appear as shown in Figure 13, the installation was successful and both **Anaconda** and **Python** are running properly *(Note: our versions may differ)*.

***

### <a id="Dependencies"></a> **4.4 Installing Dependencies**</br>


For this project we require three important dependencies: [NLTK](#NLTK) and [Pandas](https://pandas.pydata.org/ "Click to research Pandas") which we will install using the **pip** function. As we perform these installations you will appreciate one of the benefits of Anaconda, as it would have already installed some of these dependencies for us through its installation process. However, we would still need to verify them. **Before executing these commands ensure that you are connected to the internet.**

> **4.4.1 Installing Selenium**
>##### <span style="color: DarkBlue;">Purpose: Used to develop our Web Crawler
>1. Open the **Anaconda Powershell prompt** *(as shown in the previous steps)*.   
>1. At the command prompt **type** the following command and press **enter**: </br>
     ```pip install selenium
     ```

Once the installation is complete it will return you to the **command prompt**. Next,  we need to install the **Natural Language Tool Kit (NLTK)**.  
</br>
> **4.4.2. Installing NLTK**
>##### <span style="color: DarkBlue;">Purpose: Uses NLP algorithms to transform the dataset.
>1. At the command prompt **type** the following command and press **enter**: </br>
     ```pip install NLTK
     ```
#### <span style="color: DarkBlue;"> NLTK should have already been installed when we installed Anaconda. However, we are simply executing this command to verify the installation.
</br>

Once the installation is complete it will return to the **command prompt**. The final dependency that we need to install is **Pandas**.
> **4.4.3. Installing Pandas**
>##### <span style="color: DarkBlue;">Purpose: Used to structure our data into datasets for data transformation.
  
>1. At the command prompt **type** the following command and press **enter**: </br>
     ```pip install pandas
     ```
#### <span style="color: DarkBlue;"> Pandas should have already been installed when we installed Anaconda. However, we are simply executing this command to verify the installation.  
</br>

**Now that our dependencies have been installed, we are finally ready for the Python code to string everything together.**
</br>
***

### <a id="DevCrawler"></a>  **4.5 Implementing the Web Crawler** </br>
 In this subsection we present and briefly explain the code used to develop the specialized web crawler for CSRD in terms of <b>*programming comments*</b> shown in the extract, . The crawler is designed to generate random strings of 15 characters in length to be automatically entered into the Spammimic webpage using **Selenium**.

 The crawler then creates a local destination directory to store the extracted Spammimic-Encoded messages. For purposes of efficiency we have limited the number of encoded messages to just two. You may however adjust this number in the **Selenium.py** script to any number of encoded messages.

### **Web Crawler - Spammimic - (Selenium.py)**
```Python
#Imports the required libraries
import string    
import random
import pathlib
import os

#Resolves the path to the Selenium.py file
Path= pathlib.Path('Selenium.py').parent.resolve() 

#Creates the directory to source the encoded Spammimic messages
os.mkdir('encoded_sentences')
NewPath = (str(Path)+'\encoded_sentences')
print(NewPath)

#Enter number of sentences you want to generate
num_sentences = 2

#Creates the sentences array
sentences = []

#Autogenerates the characters to inserted into Spammimic t
for i in range(num_sentences):
    S = 15
    text = ''.join(random.choices(string.ascii_uppercase + string.digits + string.ascii_lowercase, k = S))
    sentences.append(text)
    
# Uses Selenium to perform the Data Extraction from Spammimic and stores the extracted files onto the local drive
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
encoded_sentences = []
i=0
for sent in sentences:
    i += 1
    file_to_write = open(str(NewPath) +"/pos_"+str(i)+".txt", "w")
    driver = webdriver.Chrome()
    driver.get("https://www.spammimic.com/")

# The complete code can be found in the Selenium.py script located in the \Selenium folder of the lesson package.
```
> ### **Crawler Execution Steps**
>1. Open the **Anaconda Navigator**
>1. From the Navigator dashboard launch **"Spyder"** *(a power Python Development Environment)* by clicking on the **Launch** button of the **Spyder Panel**.
>1. In **Spyder**, click on the **File Menu**, then **Open** or press **Ctrl+O** on your keyboard to open the file directory.
>1. Search for the lesson package provided. In the subfolder named **Selenium** double-click on the **Selenium.py** file. This will load the Python script. 
>1. Ensure that the **chromedriver.exe** file is in the same directory as the **Selenium.py** file. **Do not delete or move it.**
>1. Lastly, press **F5** on your keyboard or click on the **Run** icon to execute the Python script.
> ### <span style="color: DarkRed;">**Important:** Do not move any files out of their current file location in the lesson package!</span>
</br>

<img src="https://github.com/FHChohan/Challenge/blob/main/Man1.png?raw=true" align="left" width="150" height="150" id="Man" /><p> 
 >### **<a id="VCrawl"></a>[Verify that the files were successfully extracted](#VCrawl):**
 >- Open the **Windows Explorer**
 >- Navigate to the **Selenium** folder.  
 >- Verify that the **encoded_sentences** folder has been created and contains the two extracted Spammimic-Encoded files.
</p></br></br>

***

### <a id="MergeData"></a>  **4.6 Merging the Extracted files** </br>

In terms of our case study, CSRD wants you to ensure that the extracted data can be easily feed into their Machine Learning algorithm for training and classification tasks. To achieve this, we first need to **merge all sourced files into a single .csv file**. Once achieved, we can later transform this file into the shape and structure defined by CSRD.

The following extract briefly explains in terms of <b>*programming comments*</b> the Python code used to merge the Spammimic-Encoded files into a single .csv file. 

  > **Note:** The **Merge.py** script assigns a label of "1" to each Spammimic-Encoded message as defined by CSRD.

</br>

### **File Merge - (Merge.py)**
```Python
#Imports the required libraries
import os
import pandas as pd
import pathlib

#Resolves the path to the Merge.py file 
Path= pathlib.Path('Merge.py').parent.resolve()
files = os.listdir(str(Path) + '\\encoded_sentences\\')
print(files)

#Uses Pandas to create the dataframe in order to merge the files. If the file has 'pos' it is marked as "1".
data = pd.DataFrame()
for file in files:
    print(file)
    label = ''
    if 'pos' in file:
        label = '1'
    elif 'neg' in file:
        label = '0'
    with open(str(Path) +'\encoded_sentences\\' + file, encoding='iso-8859-1') as f:
        text = f.read()
    data = data.append({'Text':text, 'Label':label}, ignore_index=True)
data.head(-1)

#Stores the merged dataframe into a single .csv file.
data.to_csv('dataTest.csv', index=False)
```
> ### **File Merge Execution Steps**
>1. Open the **Anaconda Navigator**
>1. From the Navigator dashboard launch **"Spyder"** by clicking on the **Launch** button of the **Spyder Panel**.
>1. In **Spyder**, click on the **File Menu**, then **Open** or press **Ctrl+O** on your keyboard to open the file directory.
>1. Search for the lesson package provided. In the subfolder named **Selenium** double-click on the **Merge.py** file. This will load the Python script into Spyder.
>1. **[Verify](#VCrawl)** that the **encoded_sentences** subdirectory and the two extracted Spammimic-Encoded files were created.
>1. Once verified, press **F5** on your keyboard or click on the **Run** icon to execute the Python script.
> #### <span style="color: DarkRed;">**Important:** Do not move any files out of their current location in the lesson package!</span>
</br>

*** 
### <a id="DataTrans"></a>**4.7 Data Transformation**
Now that we have sourced and merged the Spammimic-Encoded files into a single .csv file, our next step is to shape and transform the .csv file into a format that will allow the data scientists at CSDR to easily feed it into their machine learning algorithms. To achieve this we implement the **NLTK** library as demonstrated in our final Python script.

The following extract briefly explains in terms of <b>*programming comments*</b> the Python code used to transform the .csv file into a structured dataset commonly sourced for machine learning and classification tasks.
</br>

<img src="https://github.com/FHChohan/Challenge/blob/main/Man1.png?raw=true" align="left" width="150" height="150" id="Man" /><p> 
 >#### **Students are reminded:** Detailed discussions on the python code is not the scope of this lesson. Python was discussed comprehensively in **Module 3: Python for Data Science**. Kindly review the content. However, additional resources are suggested at the end of the practical to assist you. You may also seek the assistance of your facilitator should you have any difficulties.
</p></br></br>

### **Data Transformation - (DataTransfrom.py)**
```Python
# Data Transformation using NLTK
#import required libraries
import warnings
import pandas as pd
import re, string
from nltk.corpus import stopwords
from nltk import sent_tokenize, word_tokenize
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.corpus import wordnet
import nltk
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

#Importing the .csv file using Pandas
warnings.filterwarnings('ignore')
email_data = pd.read_csv('dataTest.csv', encoding = 'iso-8859-1')

#Specifies the number of files
print('There are', len(email_data), 'data points.')
email_data.head=(5) #displays the top 5 rows

#Creates and prints the columns based on the labels
for i, col in enumerate(email_data.columns):
    print(i, col)
print ('\n')
print(email_data['Label'].value_counts()/len(email_data))
print(email_data['Label'].value_counts())

print ('\n')
print(email_data.describe())

email_data = email_data.dropna()
email_data['length']=email_data['Text'].apply(len)
print(email_data.head())

#--------------------------------------------------------------

#Pre-processing the Dataset
#Removes Special characters, full stops and other "noise" in the text.
def processText(data):
    data = data.lower()    
    #Remove urls
    data = re.sub('((www\.[^\s]+)|(https?://[^\s]+))', '', data)    
    #Remove usernames
    data = re.sub('@[^\s]+','',data)    
    #Remove white space
    data = data.strip()    
    #Remove hashtags
    data = re.sub(r'#([^\s]+)', '', data)   
    #Remove stopwords
    data = " ".join([word for word in data.split(' ') if word not in stopwords.words('english')])
    #Remove punctuation
    data = "".join(l for l in data if l not in string.punctuation)
    #remove \n
    data= data.replace('\n', '')
    return data

email_data['Text'] = email_data['Text'].map(lambda x: processText(x))
print(email_data['Text'])

#Sentence Tokenization
email_data['Text_Sentences'] = email_data['Text'].map(lambda x: sent_tokenize(x))
print(email_data['Text_Sentences'])

# The Complete code can be found in the DataTransform.py script located in the \Selenium folder of the lesson package.
```
</br>

> ### **Data Transformation Execution Steps**
>1. Open the **Anaconda Navigator**
>1. From the Navigator Dashboard launch **"Spyder"** by clicking on the **Launch** button of the **Spyder Panel**.
>1. In **Spyder**, click on the **File Menu**, then **Open** or press **Ctrl+O** on your keyboard to open the file directory.
>1. Search for the lesson package provided. In the subfolder named **Selenium** double-click on the **TransformData.py** file. This will load the Python script. 
>1. Lastly, press **F5** on your keyboard or click on the **Run** icon to execute the Python script.
> ### <span style="color: DarkRed;">**Important:** Do not move any files out of their current location in the lesson package!</span>
</br></br>


### <span style="color: DarkBlue;"> <img src="https://github.com/FHChohan/Challenge/blob/main/Approval.png?raw=true" alt="Additional Resources" width="50" height="50" id="Resources" align=left/>**Useful Resources and Independent Research**</span> 
#####  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; *(Additional research and self practice)* <br><br>

> - #### [Anaconda Documentation](https://docs.anaconda.com/anaconda/ "Learn more about Anaconda") - Learn more about Anaconda® a package manager and an environment manager with a collection of over 7,500+ open-source packages.
> - #### [Selenium WebDriver Guide](https://www.browserstack.com/guide/selenium-webdriver-tutorial "Selenium Tutorial") - Learn more about automating web-browsers using Selenium
> - #### [Tokenization(NLP)](https://www.analyticsvidhya.com/blog/2020/05/what-is-tokenization-nlp/ "Click to learn more about NLP based Tokenization") - Learn more about the Tokenization process employed in Natural Language Processing (NLP).
> - #### [NLTK](https://www.nltk.org/ "Click to learn more about NLTK") - Learn more about the Natural Language Toolkit (NLTK)
</br>

# <a id="Conclusion"></a>  5. Conclusion
##### [^ Back to Table of Contents](#TOC)

In this lesson you were introduced to the Data Extraction and Transformation methodology commonly adopted by Data Scientists and Engineers for circumstances where specific information needs to be "manually" sourced. Being part of the Data Science field, Data Engineers are required to possess a variety of critical skills which include those learnt in this and previous lessons.

Such skills allow you to adapt to varying contexts where limited infrastructure in developing or emerging markets, governmental regulations and organisational policies limit a complete cloud-based ETL solution.
</br></br>

# <a id="Assessment"></a>  6. Assessment Activity
##### [^ Back to Table of Contents](#TOC)
</br>

As part of this lesson you are required to demonstrate your ability to modify existing tools or codes based on a given criteria as per Learning Outcome 3 (LO3). 

Please read through the following assessment tasks carefully. You are required to submit the requested evidence to your facilitator to demonstrate your competency.

> **Assessment Task #1 -  Modification of the Web Crawler (Selenium.py)**  
> 1. Modify the number of sentences required by setting it to 5.
> 1. Modify the input sentence length to 10 random characters.
> 1. Change the destination directory for the storage of the extracted files to "spammimic".

Once you have modified the Selenium.py script, run the script and submit the following as evidence to your facilitator:  
a) Copy of the modified script.
</br>

***
</br>

> **Assessment Task #2 -  Modification of the File Merger (Merge.py)**  
> 1. Modify the name of the .csv file to "MyData.csv"
> 1. Modify the classification label for all spammimic files to "X1"

Once you have modified the Merge.py script, run the script and submit the following as evidence to your facilitator:  
a) Copy of the modified script.
</br>

***
</br>

# <a id="Definitions"></a>  7. Key Definitions
##### [^ Back to Table of Contents](#TOC)
</br>

- <a id="DataEngineer"></a>  **Data Engineer** - A data engineer is an IT worker whose primary job is to prepare data for analytical or operational uses. </br>

- <a id="DataIntegration"></a>  **Data Integration** - refers to the process of combining data residing in different sources to provide users with a unified view of them. This process becomes significant in a variety of situations, which include both commercial and scientific domains.

- <a id="dataMmigration"></a>  **Data Migration** - is the process of moving data from one location to another, one format to another, or one application to another. 

- <a id="datawarehousing"></a>  **Data Warehousing** - is process for collecting and managing data from varied sources to provide meaningful business insights. A Data warehouse is typically used to connect and analyze business data from heterogeneous sources. The data warehouse is the core of the BI system which is built for data analysis and reporting (Taylor, 2021).

- <a id="datawrangling"></a>  **Data Wrangling** - also called data cleaning, data remediation, or data munging refers to a variety of processes designed to transform raw data into more readily used formats.

- <a id="DS"></a> **Data Scientist** - Data scientists are a new breed of analytical data expert who have the technical skills to solve complex problems – and the curiosity to explore what problems need to be solved (Herrington, 2020).

- <a id="ML"></a> **Machine Learning (ML)** - Machine learning is the study of computer algorithms that can learn and develop on their own with experience and data. It is considered to be a component of artificial intelligence. Machine learning algorithms create a model based on training data to make predictions or judgments without having to be explicitly programmed to do so.

- <a id="NLP"></a> **Natural Language Processing (NLP)** - theoretically motivated range of computational techniques for analyzing and representing naturally occurring texts at one or more levels of linguistic analysis for the purpose of achieving human-like language processing for a range of tasks or applications (Liddy, 2001). </br></br>

- <a id="NLTK"></a>**Natural Language Toolkit (NLTK)** -  is a leading platform for building Python programs to work with human language data. It provides easy-to-use interfaces to over 50 corpora and lexical resources such as WordNet, along with a suite of text processing libraries for classification, tokenization, stemming, tagging, parsing, and semantic reasoning

</br>

# <a id="Reference"></a>  8. References
##### [^ Back to Table of Contents](#TOC)
</br>
Lutkevich, B. & Vaughan, J., 2021. TechTarget: Data Engineer. [Online] 
Available at: https://searchdatamanagement.techtarget.com/definition/data-engineer
[Accessed 7 December 2021]. </br>

Liddy, E. D., 2001. Natural Language Processing. In: Natural Language Processing. NY: Encyclopedia of Library and Information Science. </br>

Herrington, A., 2020. SAS - What is a Data Scientist?. [Online] Available at: https://www.sas.com/en_za/insights/analytics/what-is-a-data-scientist.html
[Accessed 8 December 2021]. </br>

Qlik, 2020. Qlik : What is ETL ?. [Online] 
Available at: https://www.qlik.com/us/etl
[Accessed 10 December 2021]. <br>

Stitch, 2020. Stitch: What is data extraction?. [Online] 
Available at: https://www.stitchdata.com/resources/what-is-data-extraction/
[Accessed 9 December 2021]. <br>

Taylor, D., 2021. What is Data Warehouse? Types, Definition & Example. [Online] 
Available at: https://www.guru99.com/data-warehousing.html
[Accessed 11 December 2021]. <br>











