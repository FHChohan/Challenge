import string    
import random
import pathlib #allows us to extract the path of a file or folder
import os #allows us to perform operating system functions
Path= pathlib.Path('Selenium.py').parent.resolve() #resolves the path to the Selenium folder

#creates the required directory to source the encoded Spammimic messages
os.mkdir('spammimic')
NewPath = (str(Path)+'\spammimic')
print(NewPath)


#Enter number of sentences you want to generate
num_sentences = 5
sentences = []
for i in range(num_sentences):
    # Autogenerate number of characters in the string. This will be used to input them into Spammimic to generate
    # the encoded messages
    S = 10
    text = ''.join(random.choices(string.ascii_uppercase + string.digits + string.ascii_lowercase, k = S))
    sentences.append(text)
    
# Use Selenium to extract Spammimic encoded messages into separate text files
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
encoded_sentences = []
i=0
for sent in sentences:
    i += 1
    file_to_write = open(str(NewPath) +"/pos_"+str(i)+".txt", "w")
    driver = webdriver.Chrome()
    driver.get("https://www.spammimic.com/")
    elem = driver.find_element_by_xpath('//*[@id="guts-div"]/div[1]/a')
    elem.click()
    encode_page = driver.current_url
    driver.get(encode_page)
    elem1 = driver.find_element_by_xpath('//*[@id="guts-div"]/form/input[1]')
    elem1.send_keys(sent)
    time.sleep(3)
    elem2 = driver.find_element_by_xpath('//*[@id="guts-div"]/form/input[2]')
    elem2.click()
    elem3 = driver.find_element_by_xpath('//*[@id="cyphertext"]')
    encoded_text = elem3.text
    time.sleep(2)
    driver.close()
    file_to_write.write(encoded_text)
    file_to_write.close()