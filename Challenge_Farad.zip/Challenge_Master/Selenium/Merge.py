import os
import pandas as pd
import pathlib
Path= pathlib.Path('Merge.py').parent.resolve()
files = os.listdir(str(Path) + '\\encoded_sentences\\')
print(files)


data = pd.DataFrame()
for file in files:
    print(file)
    label = ''
    if 'pos' in file:
        label = '1'
    elif 'neg' in file:
        label = '0'
    with open(str(Path) +'\encoded_sentences\\' + file, encoding='iso-8859-1') as f:
        text = f.read()
    data = data.append({'Text':text, 'Label':label}, ignore_index=True)
data.head(-1)

data.to_csv('dataTest.csv', index=False)