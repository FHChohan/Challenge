# Module - Stegospam Classification using Word2Vec - Data Transformation

import warnings
import pandas as pd
import re, string
from nltk.corpus import stopwords
from nltk import sent_tokenize, word_tokenize
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.corpus import wordnet
import nltk
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')


#loading the Data
warnings.filterwarnings('ignore')
email_data = pd.read_csv('dataTest.csv', encoding = 'iso-8859-1')
print('There are', len(email_data), 'data points.')
email_data.head=(5) #displays the top 5 rows

for i, col in enumerate(email_data.columns):
    print(i, col)

print ('\n')
print(email_data['Label'].value_counts()/len(email_data))
print(email_data['Label'].value_counts())

print ('\n')
print(email_data.describe())


#------------------------------------------------------------------------------

#Pre-processing the Corpus

def processText(data):
    data = data.lower()    
    #Remove urls
    data = re.sub('((www\.[^\s]+)|(https?://[^\s]+))', '', data)    
    #Remove usernames
    data = re.sub('@[^\s]+','',data)    
    #Remove white space
    data = data.strip()    
    #Remove hashtags
    data = re.sub(r'#([^\s]+)', '', data)   
    #Remove stopwords
    data = " ".join([word for word in data.split(' ') if word not in stopwords.words('english')])
    #Remove punctuation
    data = "".join(l for l in data if l not in string.punctuation)
    #remove \n
    data= data.replace('\n', '')
    
    return data



email_data['Text'] = email_data['Text'].map(lambda x: processText(x))
print(email_data['Text'])

#Sentence Tokenization
email_data['Text_Sentences'] = email_data['Text'].map(lambda x: sent_tokenize(x))
print(email_data['Text_Sentences'])


#Verify that the word and actual dictionary word against wordnet
def check_eng(word):
    if wordnet.synsets(word):
        return True

def identify_tokens(email_data):
    text = email_data['Text']
    tokens = nltk.word_tokenize(text)
    # taken only words (not punctuation)
    token_words = [w for w in tokens if w.isalpha() and check_eng(w) == True]
    return token_words
email_data['Text_Words'] = email_data.apply(identify_tokens, axis=1)

#Lemmatization of the words
lemmatizer = WordNetLemmatizer() 
def lemm_list(email_data):
    my_list = email_data['Text_Words']
    lemitized_list = [lemmatizer.lemmatize(word) for word in my_list]
    return (lemitized_list)
email_data['lemmed_words'] = email_data.apply(lemm_list, axis=1)

print ('\n')
print ('Lemmatized Words')
print(email_data['lemmed_words'])

#rejoin words
def rejoin_words(email_data):
    my_list = email_data['lemmed_words']
    joined_words = ( " ".join(my_list))
    return joined_words
email_data['processed'] = email_data.apply(rejoin_words, axis=1)

print ('\n')
print ('Rejoined Words')
print(email_data['processed'].head())